<?xml version="1.0" encoding="utf-8"?><rss version="2.0"><channel><title>BNETDocs Redux News</title><link>http://www.bnetdocs.org/</link><description>Battle.Net Logon Sequences, Packets, information and protocols reference site.</description><language>en-us</language><docs>http://blogs.law.harvard.edu/tech/rss</docs><managingEditor>Kyro@DementedMinds.net</managingEditor><webMaster>Kyro@DementedMinds.net</webMaster><copyright>Site scripts and design copyrights reserved to Don Cullen. Contents copyrighted to Blizzard and their parent corporation, Vivendi. Main credits for contents goes to Arta. Demented Minds copyrights reserved to Don Cullen 2003-present. Copyright infringements will be prosecuted to the fullest extent allowable by law. Please view our legal disclaimer and terms of service.</copyright><item><title>StarCraft II: Wings of Liberty - Patch 1.1.2</title><link>http://www.bnetdocs.org/?op=news&amp;nid=73</link><description> ---Via Blizzard---

General

- Players will no longer receive achievement toasts while their status is set to &quot;Busy.&quot; 
- The messaging when attempting to load a saved game or replay from a previous version has been clarified 
- Adjusted the amount of points earned and lost by random team participants to properly reflect the strength of a player&#039;s teammates. 

Balance

PROTOSS

Buildings:

- Nexus life and shields increased from 750/750 to 1000/1000. 
- Void Ray:
... Damage level...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=73</guid></item><item><title>StarCraft II: Wings of Liberty – Patch 1.1.1</title><link>http://www.bnetdocs.org/?op=news&amp;nid=72</link><description> Via Battle.net (Blizzard):

Bug Fixes:

- Fixed an issue where Ultralisk cleave range was being unintentionally extended by larger targets. 
- Fixed an issue where the Phoenix&#039;s Graviton Beam was automatically canceled if you used it just after the Phoenix reached 50 energy. 
- Fixed an issue where queuing Return Cargo on a worker would cause it to ignore the built-in delay after it finished gathering. 
- Fixed an issue where players watching older replays or saved games would experience...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=72</guid></item><item><title>Added some missing packets</title><link>http://www.bnetdocs.org/?op=news&amp;nid=71</link><description>I have found a relatively old thread on darkblizz.org (August 6th, 2010) which seems to have stemmed from this thread on vL by Hdx, which outlined some packets that our documentation was missing.

As such, I have added these packets to our documentation:

S&gt;C 0x17 SID_READMEMORY
C&gt;S 0x17 SID_READMEMORY
S&gt;C 0x20 SID_ANNOUNCEMENT
S&gt;C 0x23 SID_WRITECOOKIE
S&gt;C 0x24 SID_READCOOKIE
C&gt;S 0x24 SID_READCOOKIE
S&gt;C 0x43 SID_WARCRAFTUNKNOWN

- Jailout2000</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=71</guid></item><item><title>StarCraft II: Wings of Liberty - Patch 1.1.0</title><link>http://www.bnetdocs.org/?op=news&amp;nid=70</link><description> Via Battle.net (Blizzard):

To get the latest news and interact with the community, visit our StarCraft II website. Be sure to check out our Game Guide for an in-depth look at StarCraft II gameplay. We wish you all the best on your journeys through the embattled Koprulu Sector! 

General

- The Standard (US) and Standard for Lefties (US) hotkey configurations are now available in all regions. 
- A new game clock has been added. Players can now instantly see how long they&#039;ve been in their...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=70</guid></item><item><title>Server Checker</title><link>http://www.bnetdocs.org/?op=news&amp;nid=69</link><description> If you have ever been to this website before, you should have noticed the BNLS Server Status panel on the right, along with the Battle.net Server Status panel. These two panels contain servers that you can use with your Battle.net bots.

Now what most people probably knew, these servers do not get updated periodically, so servers would appear online when they are truly offline, and vice versa. This is no more.

I have created a simple program that connects to any MySQL server, retrieves the...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=69</guid></item><item><title>StarCraft II: Wings of Liberty - Patch 1.0.3</title><link>http://www.bnetdocs.org/?op=news&amp;nid=68</link><description>Bug Fixes:

- Fixed an issue preventing some players from accessing offline play from the login screen.</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=68</guid></item><item><title>Minor updates</title><link>http://www.bnetdocs.org/?op=news&amp;nid=67</link><description> I had taken notice that all (most, anyway) the BNLS packets were still on the Raw-setting, meaning they were new and documentation for them was changing often.

I have since then updated all of them to the Normal-setting, which means they are documented and nothing is changing anytime soon; they are considered final and any revisions will be made in a new packet id. While I was doing this, I had also noticed that the format of most of the packets were not formatted conveniently and the related...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=67</guid></item><item><title>StarCraft II: Wings of Liberty - Patch 1.0.2</title><link>http://www.bnetdocs.org/?op=news&amp;nid=66</link><description>Bug Fixes: 

- Fixed an issue where campaign mission victories would not always trigger properly. 
- Fixed an issue where some players were unable to access single-player features. </description><guid>http://www.bnetdocs.org/?op=news&amp;nid=66</guid></item><item><title>StarCraft II: Wings of Liberty - Patch 1.0.1</title><link>http://www.bnetdocs.org/?op=news&amp;nid=65</link><description> For those who live under rocks and have not come out recently: StarCraft 2 has been released and has been out for sale since July 27th.

Via Blizzard:
--------------------------------------------------------------------------------
StarCraft II: Wings of Liberty - Patch 1.0.1 

To get the latest news and interact with the community, visit our brand new StarCraft II website (http://us.battle.net/sc2/en/). Be sure to check out our Game Guide for an in-depth look at StarCraft II gameplay. We...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=65</guid></item><item><title>StarCraft II Beta is now closed</title><link>http://www.bnetdocs.org/?op=news&amp;nid=64</link><description> The upcoming StarCraft II sequel was running in a closed beta (users had to have a beta key to get on Battle.net) open to selected players by Blizzard to be tested on their new Battle.net v2. Single-player was disabled unless you used the Galaxy Editor or used hacks/mods.

That beta (now nicknamed Phase 1) was shutdown, and later reopened with the title of Phase 2, and they said they would only run it for a few days. Well those few days are now up and the beta has been shutdown officially. Now...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=64</guid></item><item><title>Starcraft II Beta Phase 2 Open</title><link>http://www.bnetdocs.org/?op=news&amp;nid=63</link><description> Phase Two of the Starcraft II Beta was launched today.

The recent debate over Real ID is still open for discussion, however the new character code has been introduced in Patch 16, the opening patch for the just-launched Phase 2. A character code is a unique code tied to your SC2 character. It is created when you create your character and cannot be changed nor chosen by you.

On the Battle.net forums, this post by Zarhym details what Patch 16 brings to Starcraft II. The &#039;General&#039; patch information:
StarCraft...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=63</guid></item><item><title>WarCraft III Update</title><link>http://www.bnetdocs.org/?op=news&amp;nid=62</link><description> There is a new patch available for WarCraft III Reign of Chaos and WarCraft III The Frozen Throne.

Version: 1.24.4.6387--------------------------------------------------------------------------
Patch 1.24e
--------------------------------------------------------------------------

FIXES

- Fixed an exploit rendering buildings non-interactable (\&quot;tower hack\&quot;). 
- Fixed an exploit allowing a player to bypass a summon ability&#039;s 
cooldown (\&quot;summon/cooldown hack\&quot;). 
- Fixed a client crash related...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=62</guid></item><item><title>WarCraft III Update</title><link>http://www.bnetdocs.org/?op=news&amp;nid=61</link><description> There is a new patch available for WarCraft III Reign of Chaos and WarCraft III The Frozen Throne.

Version: 1.24.3.6384--------------------------------------------------------------------------
Patch 1.24d
--------------------------------------------------------------------------

FIXES

- Fixed a client crash related to queuing too many invalid build commands
  (&#039;&#039;crash hack&#039;&#039;).
The verbyte did not change, but the hashes did. For your convenience, here is both:

VerByte: 0x18
Decimal:...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=61</guid></item><item><title>Updates Needed?</title><link>http://www.bnetdocs.org/?op=news&amp;nid=60</link><description> It is evident that BNETDocs Redux is old and requires a little more updated information.

Some packets remain &quot;Research required&quot; and others remain even undocumented but known. If you know of a packet that needs more information added to it, or of any packet(s) that are not added to the documentation, please contact Jailout2000 at ValHalla Legends. He can help get it sorted out.

When you contact him, make sure you provide information such as your username, a website linking to the information...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=60</guid></item><item><title>BNETDocs Continues</title><link>http://www.bnetdocs.org/?op=news&amp;nid=59</link><description> Just wanted to let ya&#039;all know the BNETDocs domain was expiring on Oct 31, so I&#039;ve gone ahead and renewed the domain. So BNETDocs will continue to exist. Not much news to many of you, but there were some who were inquiring due to lack of updates on the BNETDocs core itself.

I realize that I&#039;ve been slow in updating, and I apologize. It hasn&#039;t been quite easy since I&#039;ve been quite busy (I work 50 hours a week at my job as tech support for a telecommunications company, recent acquisition of PoliteTalk.com,...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=59</guid></item><item><title>Just an update as to whats happening with BNLS</title><link>http://www.bnetdocs.org/?op=news&amp;nid=58</link><description> Most of you, if you use BNLS, should know that ValHalla Legends stopped hosting BNLS long ago. And now with JBLS going offline also, we are forced to depend on our own servers, or other peoples servers that we may not trust.

There is a large list of servers available at the BNLS Checker website. You can use this large list to find one that works for you. This list provides online/offline counts, percentage of uptime, owner, and even where it is located.

Another list, but is not updated as...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=58</guid></item><item><title>New WarCraft III Patch</title><link>http://www.bnetdocs.org/?op=news&amp;nid=57</link><description> There is a new patch available for WarCraft III Reign of Chaos and WarCraft III The Frozen Throne.

Version: 1.24.0.6372--------------------------------------------------------------------------
Patch 1.24
--------------------------------------------------------------------------

PC WORLD EDITOR CHANGES

- Added new JASS hash table functions to replace the lost functionality from 
   fixing unsafe type casting.
   - Hash Table - Save Item Handle
   - Hash Table - Save Unit Handle
   - ...
...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=57</guid></item><item><title>WarCraft III Warden Update</title><link>http://www.bnetdocs.org/?op=news&amp;nid=56</link><description> WarCraft III, as of April 14th, 2009, has an updated warden system. Most bots these days don&#039;t know how to handle the warden packet correctly, or don&#039;t know how to handle it at all.

Here is a log received from FooLOps 1.9.9 logged on as JailBot@Lordaeron:[17:02:05:593]BNET: Unknown packet ID:5E
[17:02:05:609]0000:  FF 5E 29 00 40 B8 FE B2 42 60 35 D6 C1 64 87 0E   ÿ^).@¸þ²B`5Ö‡
              0010:  77 4E 88 EF F4 27 B9 33 D1 9E 19 C4 2E 84 84 CC   wNˆïô&#039;¹3ÑžÄ.„„Ì
     ...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=56</guid></item><item><title>Warcraft III Patch 1.23</title><link>http://www.bnetdocs.org/?op=news&amp;nid=55</link><description> --------------------------------------------------------------------------
  WARCRAFT III: THE FROZEN THRONE VERSION HISTORY
--------------------------------------------------------------------------

--------------------------------------------------------------------------
Patch 1.23
--------------------------------------------------------------------------

FEATURES

- Battle.net now uses a new banner ad system. 

FIXES

- Fixed an exploit where an altered custom map would be...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=55</guid></item><item><title>Starcraft Patch 1.16.1</title><link>http://www.bnetdocs.org/?op=news&amp;nid=54</link><description> Starcraft and Brood War Patch Information

--------------------------------------------------------------------------------
- patch 1.16.1
--------------------------------------------------------------------------------

Feature Changes

- In-game Speed Options menu now has a \&quot;Enable CPU Throttling\&quot; checkbox. 
  Enabling this option will allow StarCraft to consume fewer CPU cycles. By 
  default this option is off.

Bug Fixes

- Fixed an issue with the reply feature where any character followed...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=54</guid></item><item><title>New Patch for Starcraft/Brood War</title><link>http://www.bnetdocs.org/?op=news&amp;nid=53</link><description> SEXP_IX86_1152_1153.mpq

Starcraft and Brood War Patch Information

--------------------------------------------------------------------------------
- patch 1.15.3
--------------------------------------------------------------------------------

  Bug Fixes
- Fixed a communication bug affecting third party leagues.
- Alt-F6 no longer stalls the game on Windows.
- Game now works correctly on versions of Mac OS X which do not support 256-color
  mode.

No change in VerByte, new BNUpdate icon.

(Reported...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=53</guid></item><item><title>Diablo II 1.12a (New Patch)</title><link>http://www.bnetdocs.org/?op=news&amp;nid=52</link><description> --------------------------------------------------------------------------
- Patch 1.12
--------------------------------------------------------------------------

     Downloadable Installer Support

- If all required Diablo 2 &#039;.MPQ&#039; files are installed on the
  hard drive, the game will no longer require the CD to play.

   For users that originally performed a &#039;Full Installation&#039;
   and wish to run without the CD, all &#039;.MPQ&#039; files should
   be copied from the Diablo 2 CDs to the Diablo 2 directory....</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=52</guid></item><item><title>Server Move Completed</title><link>http://www.bnetdocs.org/?op=news&amp;nid=51</link><description>Server move has been completed. And to save Hdx the effort of having to re-edit the packets/documents, I took the liberty of making another copy from the older server and moved it here. 

So it&#039;s all up to date. :-)

Thanks for your patience during the transfer!</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=51</guid></item><item><title>Server Move</title><link>http://www.bnetdocs.org/?op=news&amp;nid=49</link><description> In light of the frequent downtimes we&#039;ve been experiencing lately, I&#039;ve procured a new server and will be moving all domains/customers to that new server. 

What this means for BNETDocs is some downtime. This is due to DNS propagation, which will take up to 24 hours, depending on your ISP.

This also includes the BNLS redirection server. I apologize for any inconvenience, but believe me, this is the best course as I believe in reliability. If there are any issues and you&#039;re unable to report...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=49</guid></item><item><title>Happy Holidays!</title><link>http://www.bnetdocs.org/?op=news&amp;nid=48</link><description>Been quite busy with work, apologies! LordVader, Leaky, and I have all been quite busy with work. 

[Edited on 12-25-07]
Merry Christmas!

[Edited on 1-1-08]
Happy New Year&#039;s!

Still working on the new version of BNETDocs. :)</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=48</guid></item><item><title>Vivendi Games / Activision Merger</title><link>http://www.bnetdocs.org/?op=news&amp;nid=47</link><description> Vivendi Games and Activision have merged into a single company called Activision Blizzard. While the name has Blizzard in it, make no mistake, Vivendi Games is the parent company of Blizzard, and while the name has &#039;Blizzard&#039; in it, it is Vivendi Games that has merged.

Blizzard posted on their forums to the effect of saying that there will be no changes to their games, their staff, their offices, nor their development teams. Blizzard Entertainment will continue to function as a division --...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=47</guid></item><item><title>Interesting statistics...</title><link>http://www.bnetdocs.org/?op=news&amp;nid=45</link><description> I just checked the stats for the visits to BNETDocs, what I saw was interesting. Here&#039;s a list of unique visits per nationality for the month of October:

1. 	United States	352
2. 	Germany		63
3. 	Australia	53
4. 	Canada		46
5. 	Hungary		27
6. 	Poland		7
7. 	France		4
8. 	Mexico		4
9. 	Netherlands	3
10. 	Norway		3 

Personally, I was surprised to see Germany ranked second in most visits. If you&#039;re a visitor from one of the countries where English isn&#039;t the main language, my apologies...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=45</guid></item><item><title>Server Crash</title><link>http://www.bnetdocs.org/?op=news&amp;nid=44</link><description>There was a server crash while I was conducting maintenance, and the backup file got corrupt. Fortunately, I had an older copy of backup. So with the assistance of Leaky, I was able to do a full server wipe and restore. 

So if you see anything that&#039;s broken, point it out so I can fix it! I&#039;ve created a document called &#039;To Fix&#039;, so post a comment there so I can get the heads up. </description><guid>http://www.bnetdocs.org/?op=news&amp;nid=44</guid></item><item><title>Comment Scripts Complete</title><link>http://www.bnetdocs.org/?op=news&amp;nid=43</link><description>Users now can comment on packets and documents. Editors and administrators also now have ability to delete comments. Enjoy.</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=43</guid></item><item><title>CSS Themes</title><link>http://www.bnetdocs.org/?op=news&amp;nid=42</link><description> CSS Themes will be now rendered as external CSS files rather than internal. What this means for you is that if you make use of one of the pre-set themes, such as the Dark Redux theme, and changes are made to it, your CSS Theme will automatically reflect the changes. 

However, due to the old CSS system, users&#039; CSS Themes were saved as internal CSS, so if you&#039;d like to switch over to the current CSS pre-set Themes and have your CSS pre-set Theme automatically reflect the changes, just go to CSS...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=42</guid></item><item><title>0x5E Warden Packet Reactivated</title><link>http://www.bnetdocs.org/?op=news&amp;nid=38</link><description> (08/22/07) Usually, if you connected to battle.net via a bot emulating Starcraft, you&#039;d be disconnected for failure to properly respond to the 0x5E Warden packet. 

It appears that that very packet has been muted for now, so people can connect to battle.net via bots emulating the Starcraft game client. There is currently no estimate on how long the packet will remain muted. 

I&#039;ve run tests, and am able to confirm the packet has indeed been muted.

(08/29/07) Edit: The 0x5E Warden packet...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=38</guid></item><item><title>StarCraft Patched to 1.15.1</title><link>http://www.bnetdocs.org/?op=news&amp;nid=37</link><description> StarCraft was patched to 1.15.1, information on known changes to StarCraft below. No verbyte change. The new offset for the byte to change for No-CDs to work on battle.net is 0x1502F6FB as reported by Andy.

-------------------------------
Patch 1.15.1
-------------------------------
   
   Bug Fixes
   
 - Fixed a replay saving bug that occasionally crashed games.
 - Fixed a bug where the map download progress was not shown.
 - Pressing alt-f4 while in Starcraft and logged into a league now...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=37</guid></item><item><title>BNLS Redirector Service Upgraded</title><link>http://www.bnetdocs.org/?op=news&amp;nid=36</link><description> I have news for those who make use of the redirective domain of bnls.dementedminds.net. 

For those who prefer a short and sweet/simple notice:

The service is upgraded to be 100% automated, and no longer manually redirected. 

For those who like details:

I originally was updating the domain to redirect to the next available bnls system manually, as a result, if a server went down, there&#039;d be a considerable delay before I found out about it being down, and updated it to redirect to another...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=36</guid></item><item><title>Starcraft/Brood War Patch 1.15</title><link>http://www.bnetdocs.org/?op=news&amp;nid=29</link><description> Game: Starcraft, Starcraft: BroodWar
Version: 1.15
VerByte: 0xD1
Archive: SEXP_IX86_114_115.mpq

-------------------------------------------------
- Patch 1.15.0
-------------------------------------------------

  Feature Changes

- Approved organizations can now operate StarCraft leagues. See
  http://www.battle.net.
- Replays are automatically saved as LastReplay.rep.


  Bug Fixes

- Fixed a bug that allowed burrowed units to be stacked.

  Exploits

- Fixed a vulture exploit that crashed...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=29</guid></item><item><title>BNLS Updates</title><link>http://www.bnetdocs.org/?op=news&amp;nid=5</link><description>BNLS has been upgraded for the latest &quot;lockdown&quot; changes on the Battle.net servers. Bot developers may now use it for requesting fast version checks on all supporting products. At this time, Diablo II, WarCraft III, and their expansions do not make use of the latest updates.

The documentation has been updated with BNLS messages BNLS_VERSIONCHECKEX and BNLS_VERSIONCHECKEX2 to support the changes.</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=5</guid></item><item><title>Re: The Lockdown Update</title><link>http://www.bnetdocs.org/?op=news&amp;nid=4</link><description> As most of you will know, Blizzard recently updated their Checkrevision procedure for WarCraft II, StarCraft, Brood War, Diablo I and StarCraft Shareware. This new method, dubbed &quot;Lockdown&quot;, is considerably more complex then the previous ix86ver method which is still used by other Battle.net-enabled products. 

We fully intend to update BNETDocs with as much information about Lockdown as possible, however, much of this material has not yet been made public. BNETDocs has always relied on information...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=4</guid></item><item><title>We&#039;re still alive!</title><link>http://www.bnetdocs.org/?op=news&amp;nid=3</link><description>Yes, we&#039;re still here for those of you who still wander across the documents. Just last night and this morning I had updated many of our already existing packets with more information/better descriptions/correctness, etc. It sure has been quiet around here, but trust me, BNETDocs still lives :)</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=3</guid></item><item><title>Diablo 2/LoD 1.11</title><link>http://www.bnetdocs.org/?op=news&amp;nid=2</link><description>Most of the packets have been updated for patch version 1.11. However, I&#039;m still counting on the public to comment in any way, shape or form on the accuracy of the information.</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=2</guid></item><item><title>StarCraft 1.13 released</title><link>http://www.bnetdocs.org/?op=news&amp;nid=1</link><description>Sorry guys for the late post on this, but just to keep everyone informed: sometime last week a patch was released for StarCraft and Brood War. BNETDocs and BNLS have been updated for the changes.</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=1</guid></item></channel></rss>