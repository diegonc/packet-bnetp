<?xml version="1.0" encoding="utf-8"?><rss version="2.0"><channel><title>BNETDocs Redux News</title><link>http://www.bnetdocs.org/</link><description>Battle.Net Logon Sequences, Packets, information and protocols reference site.</description><language>en-us</language><docs>http://blogs.law.harvard.edu/tech/rss</docs><managingEditor>Kyro@DementedMinds.net</managingEditor><webMaster>Kyro@DementedMinds.net</webMaster><copyright>Site scripts and design copyrights reserved to Don Cullen. Contents copyrighted to Blizzard and their parent corporation, Vivendi. Main credits for contents goes to Arta. Demented Minds copyrights reserved to Don Cullen 2003-present. Copyright infringements will be prosecuted to the fullest extent allowable by law. Please view our legal disclaimer and terms of service.</copyright><item><title>New WarCraft III Patch</title><link>http://www.bnetdocs.org/?op=news&amp;nid=57</link><description> There is a new patch available for WarCraft III Reign of Chaos and WarCraft III The Frozen Throne.

Version: 1.24.0.6372--------------------------------------------------------------------------
Patch 1.24
--------------------------------------------------------------------------

PC WORLD EDITOR CHANGES

- Added new JASS hash table functions to replace the lost functionality from 
   fixing unsafe type casting.
   - Hash Table - Save Item Handle
   - Hash Table - Save Unit Handle
   - ...
...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=57</guid></item><item><title>WarCraft III Warden Update</title><link>http://www.bnetdocs.org/?op=news&amp;nid=56</link><description> WarCraft III, as of April 14th, 2009, has an updated warden system. Most bots these days don&#039;t know how to handle the warden packet correctly, or don&#039;t know how to handle it at all.

Here is a log received from FooLOps 1.9.9 logged on as JailBot@Lordaeron:[17:02:05:593]BNET: Unknown packet ID:5E
[17:02:05:609]0000:  FF 5E 29 00 40 B8 FE B2 42 60 35 D6 C1 64 87 0E   ÿ^).@¸þ²B`5Ö‡
              0010:  77 4E 88 EF F4 27 B9 33 D1 9E 19 C4 2E 84 84 CC   wNˆïô&#039;¹3ÑžÄ.„„Ì
     ...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=56</guid></item><item><title>Warcraft III Patch 1.23</title><link>http://www.bnetdocs.org/?op=news&amp;nid=55</link><description> --------------------------------------------------------------------------
  WARCRAFT III: THE FROZEN THRONE VERSION HISTORY
--------------------------------------------------------------------------

--------------------------------------------------------------------------
Patch 1.23
--------------------------------------------------------------------------

FEATURES

- Battle.net now uses a new banner ad system. 

FIXES

- Fixed an exploit where an altered custom map would be...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=55</guid></item><item><title>Starcraft Patch 1.16.1</title><link>http://www.bnetdocs.org/?op=news&amp;nid=54</link><description> Starcraft and Brood War Patch Information

--------------------------------------------------------------------------------
- patch 1.16.1
--------------------------------------------------------------------------------

Feature Changes

- In-game Speed Options menu now has a \&quot;Enable CPU Throttling\&quot; checkbox. 
  Enabling this option will allow StarCraft to consume fewer CPU cycles. By 
  default this option is off.

Bug Fixes

- Fixed an issue with the reply feature where any character followed...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=54</guid></item><item><title>New Patch for Starcraft/Brood War</title><link>http://www.bnetdocs.org/?op=news&amp;nid=53</link><description> SEXP_IX86_1152_1153.mpq

Starcraft and Brood War Patch Information

--------------------------------------------------------------------------------
- patch 1.15.3
--------------------------------------------------------------------------------

  Bug Fixes
- Fixed a communication bug affecting third party leagues.
- Alt-F6 no longer stalls the game on Windows.
- Game now works correctly on versions of Mac OS X which do not support 256-color
  mode.

No change in VerByte, new BNUpdate icon.

(Reported...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=53</guid></item><item><title>Diablo II 1.12a (New Patch)</title><link>http://www.bnetdocs.org/?op=news&amp;nid=52</link><description> --------------------------------------------------------------------------
- Patch 1.12
--------------------------------------------------------------------------

     Downloadable Installer Support

- If all required Diablo 2 &#039;.MPQ&#039; files are installed on the
  hard drive, the game will no longer require the CD to play.

   For users that originally performed a &#039;Full Installation&#039;
   and wish to run without the CD, all &#039;.MPQ&#039; files should
   be copied from the Diablo 2 CDs to the Diablo 2 directory....</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=52</guid></item><item><title>Server Move Completed</title><link>http://www.bnetdocs.org/?op=news&amp;nid=51</link><description>Server move has been completed. And to save Hdx the effort of having to re-edit the packets/documents, I took the liberty of making another copy from the older server and moved it here. 

So it&#039;s all up to date. :-)

Thanks for your patience during the transfer!</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=51</guid></item><item><title>Server Move</title><link>http://www.bnetdocs.org/?op=news&amp;nid=49</link><description> In light of the frequent downtimes we&#039;ve been experiencing lately, I&#039;ve procured a new server and will be moving all domains/customers to that new server. 

What this means for BNETDocs is some downtime. This is due to DNS propagation, which will take up to 24 hours, depending on your ISP.

This also includes the BNLS redirection server. I apologize for any inconvenience, but believe me, this is the best course as I believe in reliability. If there are any issues and you&#039;re unable to report...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=49</guid></item><item><title>Happy Holidays!</title><link>http://www.bnetdocs.org/?op=news&amp;nid=48</link><description>Been quite busy with work, apologies! LordVader, Leaky, and I have all been quite busy with work. 

[Edited on 12-25-07]
Merry Christmas!

[Edited on 1-1-08]
Happy New Year&#039;s!

Still working on the new version of BNETDocs. :)</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=48</guid></item><item><title>Vivendi Games / Activision Merger</title><link>http://www.bnetdocs.org/?op=news&amp;nid=47</link><description> Vivendi Games and Activision have merged into a single company called Activision Blizzard. While the name has Blizzard in it, make no mistake, Vivendi Games is the parent company of Blizzard, and while the name has &#039;Blizzard&#039; in it, it is Vivendi Games that has merged.

Blizzard posted on their forums to the effect of saying that there will be no changes to their games, their staff, their offices, nor their development teams. Blizzard Entertainment will continue to function as a division --...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=47</guid></item><item><title>Interesting statistics...</title><link>http://www.bnetdocs.org/?op=news&amp;nid=45</link><description> I just checked the stats for the visits to BNETDocs, what I saw was interesting. Here&#039;s a list of unique visits per nationality for the month of October:

1. 	United States	352
2. 	Germany		63
3. 	Australia	53
4. 	Canada		46
5. 	Hungary		27
6. 	Poland		7
7. 	France		4
8. 	Mexico		4
9. 	Netherlands	3
10. 	Norway		3 

Personally, I was surprised to see Germany ranked second in most visits. If you&#039;re a visitor from one of the countries where English isn&#039;t the main language, my apologies...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=45</guid></item><item><title>Server Crash</title><link>http://www.bnetdocs.org/?op=news&amp;nid=44</link><description>There was a server crash while I was conducting maintenance, and the backup file got corrupt. Fortunately, I had an older copy of backup. So with the assistance of Leaky, I was able to do a full server wipe and restore. 

So if you see anything that&#039;s broken, point it out so I can fix it! I&#039;ve created a document called &#039;To Fix&#039;, so post a comment there so I can get the heads up. </description><guid>http://www.bnetdocs.org/?op=news&amp;nid=44</guid></item><item><title>Comment Scripts Complete</title><link>http://www.bnetdocs.org/?op=news&amp;nid=43</link><description>Users now can comment on packets and documents. Editors and administrators also now have ability to delete comments. Enjoy.</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=43</guid></item><item><title>CSS Themes</title><link>http://www.bnetdocs.org/?op=news&amp;nid=42</link><description> CSS Themes will be now rendered as external CSS files rather than internal. What this means for you is that if you make use of one of the pre-set themes, such as the Dark Redux theme, and changes are made to it, your CSS Theme will automatically reflect the changes. 

However, due to the old CSS system, users&#039; CSS Themes were saved as internal CSS, so if you&#039;d like to switch over to the current CSS pre-set Themes and have your CSS pre-set Theme automatically reflect the changes, just go to CSS...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=42</guid></item><item><title>0x5E Warden Packet Reactivated</title><link>http://www.bnetdocs.org/?op=news&amp;nid=38</link><description> (08/22/07) Usually, if you connected to battle.net via a bot emulating Starcraft, you&#039;d be disconnected for failure to properly respond to the 0x5E Warden packet. 

It appears that that very packet has been muted for now, so people can connect to battle.net via bots emulating the Starcraft game client. There is currently no estimate on how long the packet will remain muted. 

I&#039;ve run tests, and am able to confirm the packet has indeed been muted.

(08/29/07) Edit: The 0x5E Warden packet...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=38</guid></item><item><title>StarCraft Patched to 1.15.1</title><link>http://www.bnetdocs.org/?op=news&amp;nid=37</link><description> StarCraft was patched to 1.15.1, information on known changes to StarCraft below. No verbyte change. The new offset for the byte to change for No-CDs to work on battle.net is 0x1502F6FB as reported by Andy.

-------------------------------
Patch 1.15.1
-------------------------------
   
   Bug Fixes
   
 - Fixed a replay saving bug that occasionally crashed games.
 - Fixed a bug where the map download progress was not shown.
 - Pressing alt-f4 while in Starcraft and logged into a league now...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=37</guid></item><item><title>BNLS Redirector Service Upgraded</title><link>http://www.bnetdocs.org/?op=news&amp;nid=36</link><description> I have news for those who make use of the redirective domain of bnls.dementedminds.net. 

For those who prefer a short and sweet/simple notice:

The service is upgraded to be 100% automated, and no longer manually redirected. 

For those who like details:

I originally was updating the domain to redirect to the next available bnls system manually, as a result, if a server went down, there&#039;d be a considerable delay before I found out about it being down, and updated it to redirect to another...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=36</guid></item><item><title>Starcraft/Brood War Patch 1.15</title><link>http://www.bnetdocs.org/?op=news&amp;nid=29</link><description> Game: Starcraft, Starcraft: BroodWar
Version: 1.15
VerByte: 0xD1
Archive: SEXP_IX86_114_115.mpq

-------------------------------------------------
- Patch 1.15.0
-------------------------------------------------

  Feature Changes

- Approved organizations can now operate StarCraft leagues. See
  http://www.battle.net.
- Replays are automatically saved as LastReplay.rep.


  Bug Fixes

- Fixed a bug that allowed burrowed units to be stacked.

  Exploits

- Fixed a vulture exploit that crashed...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=29</guid></item><item><title>BNLS Updates</title><link>http://www.bnetdocs.org/?op=news&amp;nid=5</link><description>BNLS has been upgraded for the latest &quot;lockdown&quot; changes on the Battle.net servers. Bot developers may now use it for requesting fast version checks on all supporting products. At this time, Diablo II, WarCraft III, and their expansions do not make use of the latest updates.

The documentation has been updated with BNLS messages BNLS_VERSIONCHECKEX and BNLS_VERSIONCHECKEX2 to support the changes.</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=5</guid></item><item><title>Re: The Lockdown Update</title><link>http://www.bnetdocs.org/?op=news&amp;nid=4</link><description> As most of you will know, Blizzard recently updated their Checkrevision procedure for WarCraft II, StarCraft, Brood War, Diablo I and StarCraft Shareware. This new method, dubbed &quot;Lockdown&quot;, is considerably more complex then the previous ix86ver method which is still used by other Battle.net-enabled products. 

We fully intend to update BNETDocs with as much information about Lockdown as possible, however, much of this material has not yet been made public. BNETDocs has always relied on information...</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=4</guid></item><item><title>We&#039;re still alive!</title><link>http://www.bnetdocs.org/?op=news&amp;nid=3</link><description>Yes, we&#039;re still here for those of you who still wander across the documents. Just last night and this morning I had updated many of our already existing packets with more information/better descriptions/correctness, etc. It sure has been quiet around here, but trust me, BNETDocs still lives :)</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=3</guid></item><item><title>Diablo 2/LoD 1.11</title><link>http://www.bnetdocs.org/?op=news&amp;nid=2</link><description>Most of the packets have been updated for patch version 1.11. However, I&#039;m still counting on the public to comment in any way, shape or form on the accuracy of the information.</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=2</guid></item><item><title>StarCraft 1.13 released</title><link>http://www.bnetdocs.org/?op=news&amp;nid=1</link><description>Sorry guys for the late post on this, but just to keep everyone informed: sometime last week a patch was released for StarCraft and Brood War. BNETDocs and BNLS have been updated for the changes.</description><guid>http://www.bnetdocs.org/?op=news&amp;nid=1</guid></item></channel></rss>